class GameData {
    constructor() {
        this.monstersKilled = 0;
        this.playTime = 0;
        this.stageCount = 0;

    }
}